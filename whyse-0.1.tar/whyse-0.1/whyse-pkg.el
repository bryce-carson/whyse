(define-package "whyse" "0.1" "noWeb HYpertext System in Emacs"
  '((emacs "25.1")
    (emacsql "20230220")
    (peg "1.0.1")
    (cl-lib "1.0")))
