;;; whyse.el --- noWeb HYpertext System in Emacs -*- lexical-binding: nil -*-
;; Yes, you read that right: no lexical binding in this file.

;; Copyright © 2023 Bryce Carson

;; Author: Bryce Carson <bcars268@mtroyal.ca>
;; Created 2023-06-18
;; Keywords: tools tex hypermedia
;; URL: https://github.com/bryce-carson/whyse

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or
;; modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation, either version 3 of the
;; License, or (at your option) any later version.

;; This program is distributed in the hope that it will be useful, but
;; WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
;; General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see
;; <https://www.gnu.org/licenses/>.

;;; Commentary:
;; WHYSE was described by Brown and Czedjo in _A Hypertext for Literate
;; Programming_ (1991).
;;
;; Brown, M., Czejdo, B. (1991). A hypertext for literate programming.
;;    In: Akl, S.G., Fiala, F., Koczkodaj, W.W. (eds) Advances in
;;    Computing and Information — ICCI '90. ICCI 1990. Lecture Notes in
;;    Computer Science, vol 468. Springer, Berlin, Heidelberg.
;;    https://doi-org.libproxy.mtroyal.ca/10.1007/3-540-53504-7_82.
;;
;; A paper describing this implementation---written in Noweb and browsable,
;; editable, and auditable with WHYSE, or readable in the printed form---is
;; hoped to be submitted to The Journal of Open Source Software (JOSS)
;; before the year 2024. N.B.: the paper will include historical
;; information about literate programming, and citations (especially
;; of those given credit here for ideating WHYSE itself).

(defun w--nth-document-file-name (nth-document parse-tree)
  "Return the file name of the nth-indexed document in the parse tree.

For the first document in the parse tree, that is the
zeroth-indexed document."
  (cl-first (nth nth-document parse-tree)))

(defun w--nth-document (nth-document parse-tree)
  "Return the subtree of the nth-indexed document in the parse tree."
  (cl-second (nth nth-document parse-tree)))

(defun w--nth-chunk-of-document (n document)
  "Return the subtree for the Nth chunk of a noweb document parse subtree."
  (nth n document))

(defun w--chunk-number (chunk)
  "Return the chunk number of CHUNK."
  (or (cdr (assq 'code chunk))
      (cdr (assq 'docs chunk))))

(defun w--nth-chunk-of-nth-noweb-document (nth-chunk nth-document parse-tree)
  (w--nth-chunk-of-document nth-chunk (w--nth-document nth-document parse-tree)))

(defun w--chunk-text (chunk)
  "Join all the strings returned from the collection in the loop,
and return the single string."
  (string-join
   (cl-loop for elt in chunk collect
            (when (and (listp elt) (equal 'text (car elt)))
              (cdr elt)))
   ""))

(defun w--chunk-name (chunk)
  "Return non-nil if CHUNK is a code chunk, and thereby has a name.

The return value, if non-nil, is actually the name of the chunk."
  (if-let ((name (assq 'chunk chunk)))
      (cdr name)))

(defun w--concatenate-text-tokens (new-token)
  "Join the values of two text token associations in a two-element token alist.

If the two associations shouldn't be joined, return them to the stack."
  (prog1
      ;; Concatenation only occurs when the previous token examined was
      ;; a text or nwnl token, ergo there must have been a text or nwnl
      ;; token previously examined for any concatenation to occur. When
      ;; no such token has been examined immediately return the
      ;; (stringy) token recieved and indicate it must have been a
      ;; stringy token by chaning the value of `w--first-stringy-token?'
      ;; accordingly. Subsequent runs will then operate on potential
      ;; pairs of stringy tokens.
      (if-let ((not-first-stringy-token? (not w--first-stringy-token?))
               (previous-token  (pop peg--stack))
               ;; The previous token cannot be a text or nwnl token if
               ;; it is not a list, and checking prevents causing an
               ;; error by taking the `car' of a non-list token, e.g. the
               ;; filename token.
               (previous-token-is-alist?
                (prog1 (and (listp previous-token)
                            (listp new-token)
                            (or (assoc 'text `(,new-token))
                                (assoc 'nl `(,new-token)))
                            (or (assoc 'text `(,previous-token))
                                (assoc 'nl `(,previous-token)))))))
          ;; Join the association's values and let the caller push a single
          ;; token back onto the `peg--stack'.
          (cons 'text (format "%s%s" (cdr previous-token)
                              (cdr new-token)))

        ;; Push the previous token back to the `peg--stack', and let the
        ;; caller push the new token to that stack.
        (push previous-token peg--stack)
        new-token)
    (when w--first-stringy-token? (setq w--first-stringy-token? nil))))

;; TODO 2024-05-13: this function is really rough. It still needs a
;; working algorithm to search through the noweb text to find the
;; section that a chunk belongs to. I think that searching for all of
;; the sections that preceed a chunk definition will be necessary before
;; finding the last section command that preceeds a chunk (thereby
;; finding the section the chunk belongs to). There may be a better
;; algorithm; this is the first algorithm I thought of to find the
;; section that a chunk belongs to regardless of the regular expression
;; used.
;;
;; Another algorithm might use Emacs Lisp regular expressions to search
;; for the first match to any of the set of regular expressions that
;; would search for a given sectioning command.
;;
;; For now, I trust the Emacs Lisp manual when it says that `regex-opt'
;; is efficient; it is damned convenient right now.
(defun w--chunk-section (chunk-name)
  (with-temp-buffer
    (insert-file-contents (w-project-noweb project))
    (re-search-forward
     ;; It is an error if no chunks are found.
     (regexp-opt (list (concat "<" "<" chunk-name ">" ">" "="))))
    (re-search-backward
     (regexp-opt (w-project-sectioning-commands-regexs project))
     ;; It is not an error if no section is found because sectioning is
     ;; entirely optional in a literate document with LaTeX.
     nil t)
    (buffer-substring (line-beginning-position) (line-end-position))))

;;; Code:
;;;; Compiler directives
(eval-when-compile (require 'wid-edit))

;;;; Internals
(defgroup whyse nil
  "noWeb HYpertext System in Emacs"
  :tag "WHYSE"
  :group 'applications)

(defcustom w-registered-projects nil
  "This variable stores all of the projects that are known to WHYSE."
  :group 'whyse
  :type '(repeat w--project-widget)
  :require 'widget
  :tag "WHYSE Registered Projects")

(defcustom w-load-default-project? t
  "Non-nil values mean the system will load the default project.

nil will cause the interactive command `whyse' to open Customize on
its group of variables."
  :type 'boolean
  :group 'whyse
  :tag "Load default project when `whyse' is invoked?")

(defcustom w-open-customize-when-no-projects-defined? t
  "Non-nil values mean the system will open Customize as necessary.

nil will cause `whyse' to simply do nothing when no project is
defined."
  :type 'boolean
  :group 'whyse
  :tag "Open Customize to the whyse group when `whyse' is invoked and no projects are defined?")
(defvar w--parse-success t
  "The success or failure of the last parsing of noweb tool syntax.")
(define-widget 'w--project-widget 'list
  "The WHYSE project widget type."
  :format "\n%v\n"
  :offset 0
  :indent 0

  ;; NOTE: the convert-widget keyword with the argument
  ;; 'widget-types-convert-widget is absolutely necessary for ARGS to be
  ;; converted to widgets.
  :convert-widget 'widget-types-convert-widget
  :args '((editable-field
           :format "%t: %v"
           :tag "Name"
           :value "")

          (file
           :tag "Noweb source file (*.nw)"
           :format "%t: %v"
           :valid-regexp ".*\\.nw$"
           :value "")

          (string
           :tag "A shell command to run a shell script to generates Noweb tool syntax"
           :format "%t: %v"
           :documentation "A shell script which will produce the
           Noweb tool syntax. Any shell commands involved with
           noweave should be included, but totex should of course
           be excluded from this script. The script should output
           the full syntax to standard output. See the Noweb
           implementation of WHYSE for explanation."
           :value "")

          (editable-list
           :tag "LaTeX sectioning commands"
           :format "%t\n%v%i\n"
           :documentation "The strings here should be the maximum length of the command
                  possible, because substrings like 'section' will not match the
                  sectioning command only. It is likely that these will have false
                  positive matches (Sectioning command might be called like
                  '\\section{}' or '\\mySectionCommand[bold]{name}'.)"
           :args ((string :tag "Sectioning command"
                          :format "%t: %v"
                          :value "\\section{"
                          ;; FIXME: even with regex-builder I can't seem
                          ;; to write a regular expression that doesn't
                          ;; reject seemingly valid strings.
                          ;; :valid-regexp "\\.*\\(\\[.*\\]\\)?{?"
                          :documentation "More than simply 'section', use '\\section{' or '\mySection[]{' at least."
                          )))
          ))

(define-widget 'w--module-header 'group
  "Code and docs module editor headerbar.

This widget represents the headerbar for the code and docs module
editor."
  :width (buffer-size)
  :tag "🍫"
  :format "%t%v"
  ;; :keymap w-widget-headerbar-map
  :value '(module-header-left module-header-center module-header-right))

(cl-defstruct w-project
  "A WHYSE project"
  ;; Fundamental
  name
  noweb
  script
  sectioning-commands-regexs
  database-file
  database-connection

  ;; Usage
  frame

  ;; Metadata
  (date-created (current-time-string))
  date-last-edited
  date-last-exported

  ;; TODO: limit with a customization variable so that it does not grow too large.
  history-sql-commands)
;; TODO: understand how and why this macro works like
;; `with-temp-buffer'; I only copied a couple things from the defintion
;; of that macro, but I don't yet understand its definition fully. I
;; will need to before I really start to understand Emacs Lisp. I do
;; understand enough, but there is a lot more to know. A whole lot.
(defmacro w-with-project (project &rest body)
  (declare (indent 0) (indent 2) (debug t))
  "Evaluates BODY with PROJECT in scope. This is like `let' except
it doesn't bind arbitrary values to arbitrary symbols. PROJECT is
taken as the symbol `project' during evaluation of BODY.

PROJECT is in scope because it is an argument of this macro. This
may or may not work as expected."
  (eval `(progn ,@body)))

;; FIXME: the current parse tree contains a `nil' after the chunk type
;; and number assoc, and that needs to be analyzed. Why is this `nil' in
;; the stack? I assume and believe it is because of the collapsing of
;; stringy tokens; when a token should be put back onto the stack it may
;; also be putting a `nil' onto the stack in the first call to the
;; function.
;;;; Parsing expression grammar (PEG) rules
(defun w--parse-current-buffer-with-rules ()
  "Parse the current buffer with the PEG defined for Noweb tool syntax."
  (with-peg-rules
      (;;; Overall Noweb structure
       (noweb (bob) (not header) (+ file) (not trailer) (eob))
       ;; Technically, file is a tagging keyword, but that classification only
       ;; makes sense in the Hacker's guide, not in the syntax.
       (file (bol) "@file" spc (substring path) nl
             (action (setq w--file-current-line 0))
             (list (and (+ chunk)
                        (list (or (and x-chunks i-identifiers)
                                  (and i-identifiers x-chunks))))
                   ;; Trailing documentation chunk and new-lines after the xref
                   ;; and index.
                   (opt chunk)
                   (opt (+ nl)))
             `(path chunk-list -- (cons path chunk-list)))
       (path (opt (or ".." ".")) (* path-component) file-name)
       (path-component (and path-separator (+ [word])))
       (path-separator ["\\/"])
       (file-name (+ (or [word] ".")))
       (chunk begin (list (* chunk-contents)) end)
       (begin (bol) "@begin" spc kind spc ordinal (eol) nl
              (action (if (string= (cl-second peg--stack) "code")
                          (setq w--peg-parser-within-codep t))))
       (end (bol) "@end" spc kind spc ordinal (eol) nl
            (action
             (setq w--peg-parser-within-codep nil))
            ;; The stack grows down and the heap grows up,
            ;; that's the yin and yang of the computer thang
            `(kind-one
              ordinal-one
              keywords
              kind-two
              ordinal-two
              --
              (if (and (= ordinal-one ordinal-two) (string= kind-one kind-two))
                  (cons (cons (if (string= kind-one "code")
                                  'code
                                'docs)
                              ordinal-one)
                        keywords)
                (error "Chunk nesting error encountered."))))
       (ordinal (substring [0-9] (* [0-9]))
                `(number -- (string-to-number number)))
       (kind (substring (or "code" "docs")))
       (chunk-contents
        (or
         ;; structural
         text
         nwnl ;; Noweb's @nl keyword, as differentiated from the rule nl := "\n".
         defn
         ;;; NOTE: previously, a note on the following line incorrectly stated
         ;;; the `use' token was related to the `identifierusedinmodule' table,
         ;;; when it is actually related to the `parentchild' table.
         use
         quotation
         ;; tagging
         line
         language
         ;; index
         i-define-or-use
         i-definitions
         ;; xref
         x-prev-or-next-def
         x-continued-definitions-of-the-current-chunk
         i-usages
         x-usages
         x-label
         x-ref
         x-notused
         ;; error
         fatal
         x-undefined))
       (text (bol) "@text" spc (substring (* (and (not "\n") (any)))) nl
             `(txt -- (w--concatenate-text-tokens (cons 'text txt))))
       (nwnl (bol) (substring "@nl") nl (action (setf w--file-current-line
                                                      (1+ w--file-current-line)))
             ;; Be sure that when thinking about the symbol `nl' here that
             ;; you're not confusing it with the peg rule nl.
             `(nl -- (w--concatenate-text-tokens (cons 'nl "\n"))))
       (defn "@defn" spc (substring !eol) nl
         `(name -- (cons 'chunk name)))

       ;; In <<whyse.el>>=, it leads to usages tokens like below:
       ;; (chunk-child-usage . "Commentary")
       ;; (chunk-child-usage . "Code")
       (use
        (bol) "@use" spc (substring !eol) nl
        `(name --
               (if name (cons 'chunk-child-usage name)
                 (error "UH-OH! There's a syntax error in the tool output!"))))
       (quotation (bol) "@quote" nl
                  (action (when w--peg-parser-within-codep
                            (error "The parser found a quotation within a code chunk. A @fatal should have been found here, but was not.")))
                  (substring (+ (and (not "@endquote") (any))))
                  (bol) "@endquote" nl
                  `(lst -- (cons 'quotation lst)))
       (line (bol) "@line" spc (substring ordinal) nl
             `(o -- (cons 'line o)))

       (language (bol) "@language" spc (substring words-eol))
       ;; Index
       (idx (bol) "@index" spc)
       (xr (bol) "@xref" spc)

       (i-define-or-use
        idx
        (substring (or "defn" "use")) spc (substring !eol) nl
        (action
         (unless w--peg-parser-within-codep
             (error "WHYSE parse error: index definition or index usage occurred outside of a code chunk.")))
        `(s1 s2 -- (cons (make-symbol s1) s2)))

       (i-definitions idx "begindefs" nl
                      (list (+ (and (+ i-isused) i-defitem)))
                      idx "enddefs" nl
                      `(definitions -- (cons 'definitions definitions)))
       (i-isused idx (substring "isused") spc (substring label) nl
                 `(u l -- (cons 'used! l)))
       (i-defitem idx (substring "defitem") spc (substring !eol) nl
                  `(d i -- (cons 'def-item i)))

       (i-usages idx "beginuses" nl
                 (list (+ (and (+ i-isdefined) i-useitem)))
                 idx "enduses" nl
                 `(usages -- (cons 'usages usages)))
       (i-isdefined idx (substring "isdefined" spc label) nl)
       (i-useitem idx (substring "useitem" spc !eol) nl) ;; !eol :== ident

       (i-identifiers idx "beginindex" nl
                      (list (+ i-entry))
                      idx "endindex" nl
                      `(l -- (cons 'i-identifiers l)))
       (i-entry idx "entrybegin" spc (substring label spc !eol) nl
                (list (+ (or i-entrydefn i-entryuse)))
                idx "entryend" nl
                `(entry-label lst -- (cons 'entry-label lst)))
       (i-entrydefn idx (substring "entrydefn") spc (substring label) nl
                    `(defn label -- (cons 'defn label)))
       (i-entryuse idx (substring "entryuse") spc (substring label) nl
                   `(use lst -- (cons 'use lst)))
       ;; @index nl was deprecated in Noweb 2.10, and @index localdefn is not
       ;; widely used (assumedly) nor well-documented, so it is unsupported by
       ;; WHYSE (contributions for improved support are welcomed).
       (i-localdefn idx "localdefn" spc !eol nl)
       (i-nl idx "nl" spc !eol nl
             (action (error (string-join
                             '("\"@index nl\" detected."
                              "This indicates hand-written @ %def syntax in the Noweb source."
                              "This syntax was deprecated in Noweb 2.10, and is entirely unsupported."
                              "Write an autodefs AWK script for the language you are using.")
                             "\n"))))

       ;; Cross-reference
       (x-label xr (substring "label" spc label) nl
                `(substr -- (cons 'x-label (cadr (split-string substr)))))
       (x-ref xr (substring "ref" spc label) nl
              `(substr --  (cons 'ref (cadr (split-string substr)))))

       ;; FIXME: improve the error handling at this point. It is not fragile
       ;; any longer, becasue most things are ignored and this is hackish;
       ;; however, the message reporting is not too helpful. It would be nice
       ;; to have _only_ the chunk name reported, and formatted with << and >>.
       ;;; Reproduction steps: make a reference to an undefined code chunk
       ;;; within another code chunk. For fixing this issue, undefined code
       ;;; chunks should also be referenced within quotations in documentation.
       (x-undefined
        xr (or "ref" "chunkbegin") spc
        (guard
         (if (string= "nw@notdef"
                      (buffer-substring-no-properties (point) (+ 9 (point))))
             (error (format "%s: %s: %s:\n@<@<%s>>"
                            "WHYSE"
                            "nw@notdef detected"
                            "an undefined chunk was referenced"
                            (buffer-substring-no-properties (progn (forward-line) (point))
                                                            (end-of-line)))))))

       (x-prev-or-next-def
        xr (substring (or "nextdef" "prevdef")) spc (substring label) nl
        `(previous-or-next-chunk-defn label -- (cons (make-symbol previous-or-next-chunk-defn) label)))

       (x-continued-definitions-of-the-current-chunk
        xr "begindefs" nl
        (list (+ (and xr (substring "defitem") spc (substring label) nl)))
        xr "enddefs" nl)

       (x-usages
        xr "beginuses" nl
        (list (+ (and xr "useitem" spc (substring label) nl)))
        xr "enduses" nl)

       (x-notused xr "notused" spc (substring !eol) nl
                  `(name -- (cons 'unused! name)))
       (x-chunks nwnl
                 nwnl
                 xr "beginchunks" nl
                 (list (+ x-chunk))
                 xr "endchunks" nl
                 `(l -- (cons 'x-chunks l)))
       (x-chunk xr "chunkbegin" spc (substring label) spc (substring !eol) nl
                (list (+ (list (and xr
                                    (substring (or "chunkuse" "chunkdefn"))
                                    `(chunk-usage-or-definition -- (make-symbol chunk-usage-or-definition))
                                    spc
                                    (substring label)
                                    nl))))
                xr "chunkend" nl)

       ;; Associates label with tag (@xref tag $LABEL $TAG)
       (x-tag xr "tag" spc label spc !eol nl)
       (label (+ (or "-" [alnum]))) ;; A label never contains whitespace.


       ;; Error
       ;; User-errors (header and trailer) and tool-error (fatal)
       ;; Header and trailer's further text is irrelevant for parsing, because they cause errors.
       (header (bol) "@header" ;; formatter options
               (action (error "[ERROR] Do not use totex or tohtml in your noweave pipeline.")))
       (trailer (bol) "@trailer" ;; formatter
                (action (error "[ERROR] Do not use totex or tohtml in your noweave pipeline.")))
       (fatal (bol) "@fatal"
              (action (error "[FATAL] There was a fatal error in the pipeline. Stash the work area and submit a bug report against Noweb, WHYSE, and other relevant tools.")))
       ;; Helpers
       (nl (eol) "\n")
       (!eol (+ (not "\n") (any)))
       (spc " "))
    (let (w--peg-parser-within-codep
          (w--first-stringy-token? t))
      (peg-run (peg noweb) #'w--parse-failure-function))))

(defun w--parse-failure-function (lst)
  (setq w--parse-success nil)
  (pop-to-buffer (clone-buffer))
  (save-excursion
    (put-text-property (point) (point-min)
                       'face 'success)

    (put-text-property (point) (point-max)
                       'face 'error)

    (goto-char (point-max))
    (message "PEXes which failed:\n%S" lst)))
(defvar w-open-project-hook '()
  "Hooks to run when `whyse' has opened a project.")
(add-hook 'w-open-project-hook 'w--prepare-sexp-sql-from-file-tokens)

(defun w--prepare-sexp-sql-from-file-tokens ()
  "Prepare an s-expression of SQL statements for `emacsql'.

The `parse-tree' from the lexical environment (or scope, given
that WHYSE is not implemented with lexical binding) is mapped
over until every file token has been processed and records have
been inserted into all four tables of the database.

This hook depends on this object being in scope: `parse-tree'.
That object is in scope when this hook runs with the default
implementation of `whyse'. (This is not meant to imply other
implementations exist [yet], only that hacked up installations
won't operate with any guarantees or according to the original
documentation. You know that, though, because you're reading the
source code and documentation for the original right now, and it
should be obvious that changing the source code should have been
accompanied with changes in the documentation.)"
  (mapcar
   (lambda (file-token)
     (let* ((file-name (car file-token))
            (chunks (cdr file-token))
            (modules (vector
                      :insert :into 'module
                      :values (mapcar #'w--vectorize-chunk-data chunks)
                      :on-conflict-do-nothing))
            (parent-child (vector
                           :insert :into 'parentchild
                           :values (w--parent-child-relationships)
                           :on-conflict-do-nothing))
            (connection (w-project-database-connection project)))
       (mapcar (lambda (seql) (emacsql connection seql))
               (list modules
                     parent-child
                     ;; identifier-used-in-module
                     ;; topic-referenced-in-module
                     ))))
   parse-tree))

(defun w--vectorize-chunk-data (chunk)
  "Convert an individual chunk to a vector of objects.

NOTE: order of arguments: [module-name module-text file-name
section displacement module-number]"
  (let ((chunk-name (w--chunk-name chunk)))
    (vector chunk-name
            (w--chunk-text chunk)
            file-name
            (when chunk-name
              (w--chunk-section chunk-name))
            nil
            (w--chunk-number chunk))))

(defun w--parent-child-relationships ()
  "Make a list of vectors of parent-child relationships.

The elements are taken from applying `w--get-chunk-uses-of-chunks' to
every chunk in the noweb."
  (apply #'append (cl-mapcar #'w--get-chunk-uses-of-chunks chunks)))

(defun w--get-chunk-uses-of-chunks (chunk)
  "Make a list of vectors of parent-child relationships.

The parent is CHUNK, and the first element of each vector in the
list will be the number of this chunk. The chunks this chunk uses
will be named in the vectors in the returned list."
  (with-temp-buffer
    (let* ((iter 0)
           (parent-uses-child (list nil))
           (chunk-number (assoc-default 'code chunk))
           (chunk-formatted (format "%S" chunk)))
      (insert chunk-formatted)
      (goto-char (point-min))
      (cl-remove
       nil
       (cl-mapcar (lambda (assoc)
                    (when (equal (car assoc) 'chunk-child-usage)
                      (vconcat (list (number-to-string chunk-number)
                                     (cdr assoc)))))
                  chunk)))))


;;;; Commands
;;;###autoload
(defun whyse ()
  "Opens the default whyse project, conditionally running hooks.

Hooks are only run if a project is actually opened. If
`w-load-default-project?' and
`w-open-customize-when-no-project-defined?' are both nil then a
warning is given and hooks are not run.

When both customization variables are non-nil, or if only
`w-load-default-project?' is nil, then Customize is opened to the
whyse group."
  (interactive)
  ;; Warn the user that their customization options have made `whyse' a
  ;; no-op function.
  (when (and (not w-load-default-project?)
             (not w-open-customize-when-no-projects-defined?))
    (warn "The customization options for `whyse' have effectively disabled the `whyse' command."))
  (if-let ((w-load-default-project?)
           (default-project (cl-first w-registered-projects))
           (project (make-w-project :name (cl-first default-project)
                                    :noweb (cl-second default-project)
                                    :script (cl-third default-project)))
           (parse-tree (with-temp-buffer
                         (insert (shell-command-to-string (w-project-script project)))
                         (goto-char (point-min))
                         (w--parse-current-buffer-with-rules))
))
      (progn
        (setf (w-project-database-connection project)
              (emacsql-sqlite (file-name-concat
                               ;; Usually ~/.emacs.d/
                               user-emacs-directory
                               ;; `nil' or the Spacemacs cache directory.
                               (when (file-directory-p (expand-file-name ".cache" user-emacs-directory))
                                 ".cache")
                               ;; PROJECT-NAME.db
                               (concat (w-project-name project)
                                       ".db"))
                              ;; TODO: make this debug log buffer into a package
                              ;; customization. NOTE: this erases the contents
                              ;; of the named buffer and then returns the buffer
                              ;; object for that buffer.
                              :debug (with-current-buffer
                                         (get-buffer-create "emacsql-sqlite-debug-log")
                                       (erase-buffer)
                                       (current-buffer))))
        (mapcar (lambda (expression)
                  (emacsql (w-project-database-connection project) expression))

                ;; A list of SQL s-expressions to create the tables.
                '([:create-table :if-not-exists module
                   ([modulename content filename sectionname displacement
                     modulenumber]
                    (:primary-key [modulenumber modulename filename]))]

                  [:create-table :if-not-exists parentchild
                   ([parent child]
                    (:primary-key [parent child]))]

                  ;; NOTE: Identifier_used_in_module is a relation with the
                  ;; attributes identifier_name and module_number. An identifier
                  ;; can be used several different ways in each module that it
                  ;; is in. It can be defined, referenced or modified. Each of
                  ;; this functions correspond to different value of the
                  ;; attribute type_of_usage. The type_of_usage attribute can
                  ;; have three values: modified, referenced, and defined.
                  ;; Line_number is an attribute of each relationship. All
                  ;; attributes are included in the key.
                  [:create-table :if-not-exists identifierusedinmodule
                   ([identifiername modulenumber linenumber typeofusage]
                    (:primary-key [identifiername modulenumber typeofusage]))]

                  ;;; HOLD: the concept of "topic" is not present in Noweb, but
                  ;;; is present in WEB. Consult CWEB documentation and the
                  ;;; original WEB documenation to see the meaning of this
                  ;;; table.
                  ;; NOTE: topic_referenced_in_module is a relation with
                  ;; attributes topic_name and module_number. The same topic may
                  ;; be in several modules and each module can contain several
                  ;; topics. Both attributes compose the primary key.
                  [:create-table :if-not-exists topicreferencedinmodule
                   ([topicname modulenumber]
                    (:primary-key [topicname modulenumber]))]))
        (run-hooks 'w-open-project-hook)
        ;; TODO: connection closure should be on a timer that is reset
        ;; everytime a `w-'prefixed function is called, or something.
        (emacsql-close (w-project-database-connection project)))
    (unless (not w-open-customize-when-no-projects-defined?)
      (customize-group 'whyse))))


(defun w--log-in-buffer (buffer-name &rest body)
  "In a new buffer named BUFFER-NAME, insert the value of evaluating BODY."
  (save-mark-and-excursion
    (with-current-buffer
        (generate-new-buffer buffer-name)
      (insert (format-message "%S" body)))))

:width (buffer-size)
:tag "🍫"
:format "%t%v"
;; :keymap w-widget-headerbar-map
:value '(module-header-left module-header-center module-header-right)

(define-widget 'w--module-header-left 'group
  "DOCSTRING"
  (link :format "%t"
        :tag (format "<<%s>>%s%s%d"
                     module-name
                     addition?
                     modified?
                     module-number)))

(define-widget 'w--module-header-center 'group
  "DOCSTRING"
  '((item :tag "module")))

(define-widget 'w--module-header-right 'group
  "DOCSTRING"
  '((item :tag "module")))

(provide 'whyse)

;; Local Variables:
;; mode: emacs-lisp
;; no-byte-compile: t
;; no-native-compile: t
;; End:
